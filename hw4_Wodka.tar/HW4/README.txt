Makefile: makes file
bridge_crossing.c: c code
bridge_crossing.exe: executable
hw4 report.docx: report w/ pseudocode